import { useNavigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'

export default function Navbar() {
  const { user, logout, darkMode, toggleDark } = useAuth()
  const navigate = useNavigate()

  const handleLogout = () => { logout(); navigate('/login') }

  if (!user) return null

  return (
    <header style={{
      position: 'fixed', top: 0, left: 0, right: 0, zIndex: 100,
      height: 60,
      background: 'linear-gradient(135deg, #4f46e5, #7c3aed)',
      display: 'flex', alignItems: 'center',
      padding: '0 24px',
      justifyContent: 'space-between',
      boxShadow: '0 2px 8px rgba(0,0,0,0.15)'
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
        <div style={{ width: 38, height: 38, background: 'rgba(255,255,255,0.2)', borderRadius: 8, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <span style={{ color: '#fff', fontWeight: 800, fontSize: 16 }}>S</span>
        </div>
        <div>
          <div style={{ color: '#fff', fontWeight: 800, fontSize: 16, lineHeight: 1 }}>SMS</div>
          <div style={{ color: 'rgba(255,255,255,0.7)', fontSize: 10, lineHeight: 1, marginTop: 2 }}>Student Management</div>
        </div>
      </div>

      <div style={{ flex: 1, maxWidth: 400, margin: '0 32px', position: 'relative' }}>
        <input
          placeholder="Search students, courses..."
          style={{ width: '100%', padding: '8px 14px', borderRadius: 20, border: 'none', fontSize: 13, background: 'rgba(255,255,255,0.15)', color: '#fff', boxSizing: 'border-box' }} />
      </div>

      <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
        <button onClick={toggleDark} style={{ padding: '6px 12px', background: 'rgba(255,255,255,0.15)', border: 'none', borderRadius: 6, cursor: 'pointer', color: '#fff', fontSize: 12, fontWeight: 500 }}>
          {darkMode ? 'Light Mode' : 'Dark Mode'}
        </button>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <div style={{ width: 34, height: 34, background: 'rgba(255,255,255,0.2)', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', fontWeight: 700, fontSize: 14 }}>
            {user?.name?.charAt(0)}
          </div>
          <div>
            <div style={{ color: '#fff', fontSize: 13, fontWeight: 600, lineHeight: 1 }}>{user?.name}</div>
            <div style={{ color: 'rgba(255,255,255,0.7)', fontSize: 10, lineHeight: 1, marginTop: 2 }}>{user?.role}</div>
          </div>
        </div>
        <button onClick={handleLogout} style={{ padding: '6px 14px', background: 'rgba(255,255,255,0.15)', color: '#fff', border: '1px solid rgba(255,255,255,0.3)', borderRadius: 6, cursor: 'pointer', fontSize: 13, fontWeight: 500 }}>
          Logout
        </button>
      </div>
    </header>
  )
}