import { Link, useLocation } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'

export default function Sidebar() {
  const { user } = useAuth()
  const location = useLocation()

  if (!user) return null

  const links = [
    { path: '/',           label: 'Home'       },
    { path: '/students',   label: 'Students'   },
    { path: '/courses',    label: 'Courses'    },
    { path: '/attendance', label: 'Attendance' },
    { path: '/grades',     label: 'Grades'     },
    { path: '/teachers',   label: 'Teachers'   },
    { path: '/fees',       label: 'Fees'       },
  ]

  return (
    <aside className="sidebar">

      {/* Profile */}
      <div style={{ padding: '24px 20px', borderBottom: '1px solid #f1f5f9', textAlign: 'center' }}>
        <div style={{ width: 60, height: 60, background: 'linear-gradient(135deg, #4f46e5, #7c3aed)', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 12px', color: '#fff', fontWeight: 700, fontSize: 22 }}>
          {user?.name?.charAt(0)}
        </div>
        <p style={{ fontSize: 14, fontWeight: 700, color: '#0f172a', marginBottom: 2 }}>{user?.name}</p>
        <p style={{ fontSize: 11, color: '#94a3b8', marginBottom: 10 }}>{user?.email}</p>
        <span style={{ fontSize: 11, background: '#ede9fe', color: '#4f46e5', padding: '3px 12px', borderRadius: 999, fontWeight: 600 }}>
          {user?.role}
        </span>
      </div>

      {/* Links */}
      <nav style={{ padding: '12px 0' }}>
        <p style={{ fontSize: 10, fontWeight: 700, color: '#cbd5e1', padding: '8px 20px 6px', letterSpacing: 1, textTransform: 'uppercase' }}>
          Navigation
        </p>
        {links.map(link => {
          const isActive = location.pathname === link.path
          return (
            <Link key={link.path} to={link.path} style={{
              display: 'block',
              padding: '10px 20px',
              fontSize: 13,
              fontWeight: isActive ? 600 : 400,
              color: isActive ? '#4f46e5' : '#64748b',
              background: isActive ? '#f5f3ff' : 'transparent',
              borderRight: isActive ? '3px solid #4f46e5' : '3px solid transparent',
              transition: 'all 0.15s'
            }}>
              {link.label}
            </Link>
          )
        })}
      </nav>

      {/* Footer */}
      <div style={{ position: 'absolute', bottom: 0, left: 0, right: 0, padding: '14px 20px', borderTop: '1px solid #f1f5f9', background: '#fff' }}>
        <p style={{ fontSize: 11, color: '#cbd5e1', textAlign: 'center' }}>SMS v1.0</p>
      </div>
    </aside>
  )
}