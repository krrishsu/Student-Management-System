import { useState } from 'react'
import { createStudent, updateStudent } from '../services/api'

export default function StudentForm({ student, onClose }) {
  const [form, setForm] = useState({
    name:       student?.name       || '',
    email:      student?.email      || '',
    rollNumber: student?.rollNumber || '',
    phone:      student?.phone      || '',
    department: student?.department || '',
    year:       student?.year       || 1,
  })
  const [loading, setLoading] = useState(false)
  const [error,   setError]   = useState('')

  const handleChange = e => setForm({ ...form, [e.target.name]: e.target.value })

  const handleSubmit = async (e) => {
    e.preventDefault()
    setLoading(true)
    setError('')
    try {
      student ? await updateStudent(student._id, form) : await createStudent(form)
      onClose()
    } catch (err) {
      setError(err.response?.data?.message || 'Something went wrong!')
    }
    setLoading(false)
  }

  const inputStyle = {
    width: '100%', padding: '10px 14px',
    border: '1.5px solid #e2e8f0', borderRadius: 8,
    fontSize: 14, boxSizing: 'border-box',
    transition: 'border 0.2s'
  }

  const labelStyle = {
    fontSize: 13, fontWeight: 600,
    color: '#374151', display: 'block', marginBottom: 6
  }

  const fields = [
    { name: 'name',       label: 'Full Name',   placeholder: 'e.g. Rahul Sharma',   type: 'text',   icon: '👤' },
    { name: 'email',      label: 'Email',       placeholder: 'e.g. rahul@gmail.com', type: 'email',  icon: '📧' },
    { name: 'rollNumber', label: 'Roll Number', placeholder: 'e.g. CS2024001',       type: 'text',   icon: '🎫' },
    { name: 'phone',      label: 'Phone',       placeholder: 'e.g. 9876543210',      type: 'text',   icon: '📱' },
    { name: 'department', label: 'Department',  placeholder: 'e.g. Computer Science', type: 'text',  icon: '🏢' },
  ]

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
        <div>
          <h3 style={{ fontSize: 18, fontWeight: 700, color: '#1e293b' }}>
            {student ? '✏️ Edit Student' : '➕ Add New Student'}
          </h3>
          <p style={{ fontSize: 13, color: '#64748b', marginTop: 2 }}>
            {student ? 'Update student information' : 'Fill in the details to add a new student'}
          </p>
        </div>
        <button onClick={onClose}
          style={{ width: 32, height: 32, background: '#f1f5f9', border: 'none', borderRadius: 8, cursor: 'pointer', fontSize: 16, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          ✕
        </button>
      </div>

      {error && (
        <div style={{ background: '#fef2f2', border: '1px solid #fecaca', color: '#dc2626', padding: '10px 16px', borderRadius: 8, marginBottom: 16, fontSize: 13 }}>
          ❌ {error}
        </div>
      )}

      <form onSubmit={handleSubmit}>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginBottom: 16 }}>
          {fields.map(field => (
            <div key={field.name}>
              <label style={labelStyle}>{field.icon} {field.label}</label>
              <input
                name={field.name}
                type={field.type}
                placeholder={field.placeholder}
                value={form[field.name]}
                onChange={handleChange}
                style={inputStyle}
                required={field.name !== 'phone'} />
            </div>
          ))}
          <div>
            <label style={labelStyle}>📅 Year</label>
            <select name="year" value={form.year} onChange={handleChange} style={inputStyle}>
              {[1,2,3,4,5].map(y => <option key={y} value={y}>Year {y}</option>)}
            </select>
          </div>
        </div>

        <div style={{ display: 'flex', gap: 10, justifyContent: 'flex-end' }}>
          <button type="button" onClick={onClose}
            style={{ padding: '10px 20px', background: '#f1f5f9', color: '#64748b', border: 'none', borderRadius: 8, cursor: 'pointer', fontSize: 14, fontWeight: 500 }}>
            Cancel
          </button>
          <button type="submit" disabled={loading}
            style={{ padding: '10px 24px', background: loading ? '#a5b4fc' : 'linear-gradient(135deg, #4f46e5, #7c3aed)', color: '#fff', border: 'none', borderRadius: 8, cursor: loading ? 'not-allowed' : 'pointer', fontSize: 14, fontWeight: 600, boxShadow: '0 4px 12px rgba(79,70,229,0.3)' }}>
            {loading ? '⏳ Saving...' : student ? '✓ Update Student' : '+ Add Student'}
          </button>
        </div>
      </form>
    </div>
  )
}