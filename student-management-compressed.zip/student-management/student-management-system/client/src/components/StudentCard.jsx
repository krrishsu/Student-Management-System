import { useNavigate } from 'react-router-dom'

export default function StudentCard({ student, onEdit, onDelete }) {
  const navigate = useNavigate()

  const gradients = [
    'linear-gradient(135deg, #667eea, #764ba2)',
    'linear-gradient(135deg, #11998e, #38ef7d)',
    'linear-gradient(135deg, #f093fb, #f5576c)',
    'linear-gradient(135deg, #4facfe, #00f2fe)',
    'linear-gradient(135deg, #fa709a, #fee140)',
    'linear-gradient(135deg, #a18cd1, #fbc2eb)',
  ]
  const idx = student.name.charCodeAt(0) % gradients.length

  return (
    <div className="card" style={{ padding: 0, overflow: 'hidden', cursor: 'pointer' }}>

      {/* Top Banner */}
      <div style={{ height: 8, background: gradients[idx] }} />

      <div style={{ padding: 20 }}>
        {/* Avatar & Name */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 16 }}
          onClick={() => navigate(`/students/${student._id}`)}>
          <div style={{ width: 48, height: 48, background: gradients[idx], borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, boxShadow: '0 4px 10px rgba(0,0,0,0.15)' }}>
            <span style={{ color: '#fff', fontWeight: 700, fontSize: 20 }}>{student.name.charAt(0)}</span>
          </div>
          <div style={{ flex: 1, minWidth: 0 }}>
            <h3 style={{ fontSize: 15, fontWeight: 600, color: '#1e293b', marginBottom: 2, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
              {student.name}
            </h3>
            <p style={{ fontSize: 12, color: '#94a3b8', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
              {student.email}
            </p>
          </div>
        </div>

        {/* Info */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8, marginBottom: 16 }}
          onClick={() => navigate(`/students/${student._id}`)}>
          {[
            { label: 'Roll No',    value: student.rollNumber },
            { label: 'Department', value: student.department },
            { label: 'Year',       value: `Year ${student.year}` },
            { label: 'Status',     value: 'Active' },
          ].map(item => (
            <div key={item.label} style={{ background: '#f8fafc', borderRadius: 8, padding: '8px 10px' }}>
              <p style={{ fontSize: 11, color: '#94a3b8', marginBottom: 2 }}>{item.label}</p>
              <p style={{ fontSize: 13, fontWeight: 500, color: '#1e293b' }}>{item.value}</p>
            </div>
          ))}
        </div>

        {/* Actions */}
        <div style={{ display: 'flex', gap: 8 }}>
          <button onClick={() => navigate(`/students/${student._id}`)}
            style={{ flex: 1, padding: '7px', background: '#f8fafc', color: '#64748b', border: '1px solid #e2e8f0', borderRadius: 8, cursor: 'pointer', fontSize: 12, fontWeight: 500 }}>
            👁 View
          </button>
          <button onClick={() => onEdit(student)}
            style={{ flex: 1, padding: '7px', background: '#ede9fe', color: '#7c3aed', border: 'none', borderRadius: 8, cursor: 'pointer', fontSize: 12, fontWeight: 500 }}>
            ✏️ Edit
          </button>
          <button onClick={() => onDelete(student._id)}
            style={{ flex: 1, padding: '7px', background: '#fee2e2', color: '#dc2626', border: 'none', borderRadius: 8, cursor: 'pointer', fontSize: 12, fontWeight: 500 }}>
            🗑 Delete
          </button>
        </div>
      </div>
    </div>
  )
}