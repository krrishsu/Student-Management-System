import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import Login          from './pages/Login'
import Dashboard      from './pages/Dashboard'
import Students       from './pages/Students'
import Courses        from './pages/Courses'
import Attendance     from './pages/Attendance'
import Grades         from './pages/Grades'
import Teachers       from './pages/Teachers'
import StudentProfile from './pages/StudentProfile'
import Fees           from './pages/Fees'
import Navbar         from './components/Navbar'
import Sidebar        from './components/Sidebar'
import { useAuth }    from './context/AuthContext'

const PrivateRoute = ({ children }) => {
  const { user } = useAuth()
  return user ? children : <Navigate to="/login" />
}

function Layout({ children }) {
  const { user } = useAuth()
  if (!user) return children
  return (
    <div className="layout">
      <Navbar />
      <div className="main-content">
        <Sidebar />
        <main className="page-content">
          {children}
        </main>
      </div>
    </div>
  )
}

export default function App() {
  return (
    <BrowserRouter>
      <Layout>
        <Routes>
          <Route path="/login"        element={<Login />} />
          <Route path="/"             element={<PrivateRoute><Dashboard      /></PrivateRoute>} />
          <Route path="/students"     element={<PrivateRoute><Students       /></PrivateRoute>} />
          <Route path="/students/:id" element={<PrivateRoute><StudentProfile /></PrivateRoute>} />
          <Route path="/courses"      element={<PrivateRoute><Courses        /></PrivateRoute>} />
          <Route path="/attendance"   element={<PrivateRoute><Attendance     /></PrivateRoute>} />
          <Route path="/grades"       element={<PrivateRoute><Grades         /></PrivateRoute>} />
          <Route path="/teachers"     element={<PrivateRoute><Teachers       /></PrivateRoute>} />
          <Route path="/fees"         element={<PrivateRoute><Fees           /></PrivateRoute>} />
        </Routes>
      </Layout>
    </BrowserRouter>
  )
}