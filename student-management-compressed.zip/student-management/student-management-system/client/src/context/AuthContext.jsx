import { createContext, useContext, useState } from 'react'

const AuthContext = createContext()

export const AuthProvider = ({ children }) => {
  const [user,     setUser]     = useState(JSON.parse(localStorage.getItem('user')) || null)
  const [darkMode, setDarkMode] = useState(false)

  const login = (userData) => {
    localStorage.setItem('user', JSON.stringify(userData))
    setUser(userData)
  }

  const logout = () => {
    localStorage.removeItem('user')
    setUser(null)
  }

  const toggleDark = () => setDarkMode(prev => !prev)

  return (
    <AuthContext.Provider value={{ user, login, logout, darkMode, toggleDark }}>
      <div style={{
        minHeight: '100vh',
        background: darkMode ? '#0f172a' : '#f8fafc',
        color:      darkMode ? '#e2e8f0' : '#1e293b',
        transition: 'background 0.3s, color 0.3s'
      }}>
        {children}
      </div>
    </AuthContext.Provider>
  )
}

export const useAuth = () => useContext(AuthContext)