import { createContext, useContext, useState } from 'react'

const NotificationContext = createContext()

export const NotificationProvider = ({ children }) => {
  const [notifications, setNotifications] = useState([])

  const addNotification = (message, type = 'success') => {
    const id = Date.now()
    setNotifications(prev => [...prev, { id, message, type }])
    setTimeout(() => {
      setNotifications(prev => prev.filter(n => n.id !== id))
    }, 3000)
  }

  const removeNotification = (id) => {
    setNotifications(prev => prev.filter(n => n.id !== id))
  }

  return (
    <NotificationContext.Provider value={{ notifications, addNotification, removeNotification }}>
      {children}

      {/* Notification Toast */}
      <div style={{ position: 'fixed', top: 20, right: 20, zIndex: 9999, display: 'flex', flexDirection: 'column', gap: 8 }}>
        {notifications.map(n => (
          <div key={n.id} style={{
            padding: '12px 20px', borderRadius: 10, fontSize: 14, fontWeight: 500,
            display: 'flex', alignItems: 'center', gap: 12, minWidth: 280,
            boxShadow: '0 4px 16px rgba(0,0,0,0.12)',
            background: n.type === 'success' ? '#dcfce7' : n.type === 'error' ? '#fee2e2' : '#e0f2fe',
            color:      n.type === 'success' ? '#15803d' : n.type === 'error' ? '#dc2626' : '#0369a1',
            animation: 'slideIn 0.3s ease'
          }}>
            <span>{n.type === 'success' ? '✅' : n.type === 'error' ? '❌' : 'ℹ️'}</span>
            <span style={{ flex: 1 }}>{n.message}</span>
            <button onClick={() => removeNotification(n.id)}
              style={{ background: 'none', border: 'none', cursor: 'pointer', fontSize: 16, color: 'inherit', padding: 0 }}>
              ×
            </button>
          </div>
        ))}
      </div>

      <style>{`
        @keyframes slideIn {
          from { transform: translateX(100%); opacity: 0; }
          to   { transform: translateX(0);    opacity: 1; }
        }
      `}</style>
    </NotificationContext.Provider>
  )
}

export const useNotification = () => useContext(NotificationContext)