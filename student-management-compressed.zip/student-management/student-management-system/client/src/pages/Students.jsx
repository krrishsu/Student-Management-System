import { useEffect, useState } from 'react'
import { getStudents, deleteStudent } from '../services/api'
import StudentForm from '../components/StudentForm'
import StudentCard from '../components/StudentCard'
import { useNotification } from '../context/NotificationContext'

export default function Students() {
  const [students,   setStudents]   = useState([])
  const [showForm,   setShowForm]   = useState(false)
  const [selected,   setSelected]   = useState(null)
  const [search,     setSearch]     = useState('')
  const [filterDept, setFilterDept] = useState('')
  const [filterYear, setFilterYear] = useState('')
  const [view,       setView]       = useState('list')
  const { addNotification } = useNotification()

  const fetchStudents = async () => {
    const { data } = await getStudents()
    setStudents(data)
  }

  useEffect(() => { fetchStudents() }, [])

  const handleDelete = async (id) => {
    if (window.confirm('Delete this student?')) {
      await deleteStudent(id)
      fetchStudents()
      addNotification('Student deleted successfully!', 'success')
    }
  }

  const handleEdit  = (student) => { setSelected(student); setShowForm(true) }
  const handleClose = () => {
    setSelected(null)
    setShowForm(false)
    fetchStudents()
    addNotification(selected ? 'Student updated!' : 'Student added!', 'success')
  }

  const departments = [...new Set(students.map(s => s.department))]

  const filtered = students.filter(s => {
    const matchSearch = s.name.toLowerCase().includes(search.toLowerCase()) ||
                        s.email.toLowerCase().includes(search.toLowerCase()) ||
                        s.rollNumber.toLowerCase().includes(search.toLowerCase())
    const matchDept = filterDept ? s.department === filterDept : true
    const matchYear = filterYear ? s.year === Number(filterYear) : true
    return matchSearch && matchDept && matchYear
  })

  const inputStyle = { padding: '9px 14px', border: '1.5px solid #e2e8f0', borderRadius: 8, fontSize: 13, outline: 'none', background: '#fff' }

  return (
    <div className="fade-in" style={{ maxWidth: 1100, margin: '0 auto' }}>

      {/* Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 28 }}>
        <div>
          <p style={{ fontSize: 12, color: '#94a3b8', marginBottom: 4 }}>Home / Students</p>
          <h2 style={{ fontSize: 22, fontWeight: 700, color: '#0f172a' }}>Students</h2>
          <p style={{ fontSize: 13, color: '#94a3b8', marginTop: 4 }}>{students.length} students enrolled</p>
        </div>
        <button onClick={() => { setSelected(null); setShowForm(true) }}
          style={{ padding: '10px 20px', background: '#4f46e5', color: '#fff', border: 'none', borderRadius: 8, fontSize: 13, fontWeight: 600, cursor: 'pointer' }}>
          + Add Student
        </button>
      </div>

      {/* Add/Edit Form */}
      {showForm && (
        <div style={{ background: '#fff', borderRadius: 12, padding: 24, marginBottom: 24, boxShadow: '0 1px 3px rgba(0,0,0,0.06)', border: '1px solid #f1f5f9' }}>
          <StudentForm student={selected} onClose={handleClose} />
        </div>
      )}

      {/* Filters */}
      <div style={{ background: '#fff', borderRadius: 12, padding: '14px 20px', marginBottom: 20, boxShadow: '0 1px 3px rgba(0,0,0,0.06)', display: 'flex', gap: 12, alignItems: 'center', flexWrap: 'wrap' }}>
        <input
          placeholder="Search by name, email or roll number..."
          value={search}
          onChange={e => setSearch(e.target.value)}
          style={{ ...inputStyle, flex: 1, minWidth: 200 }} />
        <select value={filterDept} onChange={e => setFilterDept(e.target.value)} style={inputStyle}>
          <option value="">All Departments</option>
          {departments.map(d => <option key={d} value={d}>{d}</option>)}
        </select>
        <select value={filterYear} onChange={e => setFilterYear(e.target.value)} style={inputStyle}>
          <option value="">All Years</option>
          {[1,2,3,4,5].map(y => <option key={y} value={y}>Year {y}</option>)}
        </select>
        {(search || filterDept || filterYear) && (
          <button onClick={() => { setSearch(''); setFilterDept(''); setFilterYear('') }}
            style={{ padding: '9px 14px', background: '#fee2e2', color: '#dc2626', border: 'none', borderRadius: 8, cursor: 'pointer', fontSize: 13, fontWeight: 500 }}>
            Clear
          </button>
        )}
        <div style={{ display: 'flex', gap: 4, background: '#f8fafc', borderRadius: 8, padding: 3, border: '1px solid #e2e8f0' }}>
          <button onClick={() => setView('list')}
            style={{ padding: '5px 12px', background: view === 'list' ? '#fff' : 'transparent', border: 'none', borderRadius: 6, cursor: 'pointer', fontSize: 12, fontWeight: view === 'list' ? 600 : 400, color: view === 'list' ? '#4f46e5' : '#94a3b8', boxShadow: view === 'list' ? '0 1px 2px rgba(0,0,0,0.08)' : 'none' }}>
            List
          </button>
          <button onClick={() => setView('grid')}
            style={{ padding: '5px 12px', background: view === 'grid' ? '#fff' : 'transparent', border: 'none', borderRadius: 6, cursor: 'pointer', fontSize: 12, fontWeight: view === 'grid' ? 600 : 400, color: view === 'grid' ? '#4f46e5' : '#94a3b8', boxShadow: view === 'grid' ? '0 1px 2px rgba(0,0,0,0.08)' : 'none' }}>
            Grid
          </button>
        </div>
        <p style={{ fontSize: 12, color: '#94a3b8', marginLeft: 'auto' }}>{filtered.length} of {students.length} students</p>
      </div>

      {/* List View */}
      {view === 'list' && (
        <div style={{ background: '#fff', borderRadius: 12, boxShadow: '0 1px 3px rgba(0,0,0,0.06)', overflow: 'hidden' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr style={{ borderBottom: '1px solid #f1f5f9', background: '#fafafa' }}>
                <th style={{ padding: '12px 20px', textAlign: 'left', fontSize: 11, color: '#94a3b8', fontWeight: 600, textTransform: 'uppercase', letterSpacing: 0.5 }}>Student</th>
                <th style={{ padding: '12px 20px', textAlign: 'left', fontSize: 11, color: '#94a3b8', fontWeight: 600, textTransform: 'uppercase', letterSpacing: 0.5 }}>Roll No</th>
                <th style={{ padding: '12px 20px', textAlign: 'left', fontSize: 11, color: '#94a3b8', fontWeight: 600, textTransform: 'uppercase', letterSpacing: 0.5 }}>Department</th>
                <th style={{ padding: '12px 20px', textAlign: 'left', fontSize: 11, color: '#94a3b8', fontWeight: 600, textTransform: 'uppercase', letterSpacing: 0.5 }}>Year</th>
                <th style={{ padding: '12px 20px', textAlign: 'left', fontSize: 11, color: '#94a3b8', fontWeight: 600, textTransform: 'uppercase', letterSpacing: 0.5 }}>Status</th>
                <th style={{ padding: '12px 20px', textAlign: 'left', fontSize: 11, color: '#94a3b8', fontWeight: 600, textTransform: 'uppercase', letterSpacing: 0.5 }}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map(s => (
                <tr key={s._id} style={{ borderBottom: '1px solid #f8fafc' }}>
                  <td style={{ padding: '14px 20px' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                      <div style={{ width: 34, height: 34, background: '#ede9fe', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 13, fontWeight: 700, color: '#4f46e5', flexShrink: 0 }}>
                        {s.name.charAt(0)}
                      </div>
                      <div>
                        <div style={{ fontWeight: 500, fontSize: 13, color: '#0f172a' }}>{s.name}</div>
                        <div style={{ fontSize: 11, color: '#94a3b8' }}>{s.email}</div>
                      </div>
                    </div>
                  </td>
                  <td style={{ padding: '14px 20px', fontSize: 13, color: '#64748b' }}>{s.rollNumber}</td>
                  <td style={{ padding: '14px 20px', fontSize: 13, color: '#64748b' }}>{s.department}</td>
                  <td style={{ padding: '14px 20px', fontSize: 13, color: '#64748b' }}>Year {s.year}</td>
                  <td style={{ padding: '14px 20px' }}>
                    <span style={{ background: '#dcfce7', color: '#15803d', padding: '3px 10px', borderRadius: 999, fontSize: 11, fontWeight: 600 }}>Active</span>
                  </td>
                  <td style={{ padding: '14px 20px' }}>
                    <div style={{ display: 'flex', gap: 6 }}>
                      <button onClick={() => handleEdit(s)}
                        style={{ padding: '5px 12px', background: '#ede9fe', color: '#4f46e5', border: 'none', borderRadius: 6, cursor: 'pointer', fontSize: 12, fontWeight: 500 }}>
                        Edit
                      </button>
                      <button onClick={() => handleDelete(s._id)}
                        style={{ padding: '5px 12px', background: '#fee2e2', color: '#dc2626', border: 'none', borderRadius: 6, cursor: 'pointer', fontSize: 12, fontWeight: 500 }}>
                        Delete
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {filtered.length === 0 && (
            <div style={{ textAlign: 'center', padding: 60, color: '#94a3b8' }}>
              <p style={{ fontSize: 16, fontWeight: 500, marginBottom: 6 }}>No students found</p>
              <p style={{ fontSize: 13 }}>Try a different search or add a new student</p>
            </div>
          )}
        </div>
      )}

      {/* Grid View */}
      {view === 'grid' && (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', gap: 16 }}>
          {filtered.map(s => <StudentCard key={s._id} student={s} onEdit={handleEdit} onDelete={handleDelete} />)}
          {filtered.length === 0 && (
            <div style={{ gridColumn: '1/-1', textAlign: 'center', padding: 60, color: '#94a3b8', background: '#fff', borderRadius: 12 }}>
              <p style={{ fontSize: 16, fontWeight: 500, marginBottom: 6 }}>No students found</p>
              <p style={{ fontSize: 13 }}>Try a different search or add a new student</p>
            </div>
          )}
        </div>
      )}
    </div>
  )
}