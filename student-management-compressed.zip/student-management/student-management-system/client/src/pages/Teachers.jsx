import { useState } from 'react'
import { registerUser } from '../services/api'
import { useNotification } from '../context/NotificationContext'

export default function Teachers() {
  const [teachers, setTeachers] = useState([])
  const [showForm, setShowForm] = useState(false)
  const [form,     setForm]     = useState({ name: '', email: '', password: '', role: 'teacher' })
  const [loading,  setLoading]  = useState(false)
  const { addNotification } = useNotification()

  const handleChange = e => setForm({ ...form, [e.target.name]: e.target.value })

  const handleSubmit = async (e) => {
    e.preventDefault()
    setLoading(true)
    try {
      const { data } = await registerUser(form)
      setTeachers(prev => [...prev, data])
      setForm({ name: '', email: '', password: '', role: 'teacher' })
      setShowForm(false)
      addNotification('Teacher added successfully!', 'success')
    } catch {
      addNotification('Email already exists!', 'error')
    }
    setLoading(false)
  }

  const inputStyle = {
    width: '100%', padding: '10px 14px',
    border: '1.5px solid #e2e8f0', borderRadius: 8,
    fontSize: 13, boxSizing: 'border-box', outline: 'none'
  }

  const labelStyle = {
    fontSize: 12, fontWeight: 600, color: '#64748b',
    display: 'block', marginBottom: 6,
    textTransform: 'uppercase', letterSpacing: 0.4
  }

  const deptColors = ['#4f46e5', '#0369a1', '#15803d', '#a16207', '#dc2626']

  return (
    <div className="fade-in" style={{ maxWidth: 1000, margin: '0 auto' }}>

      {/* Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 28 }}>
        <div>
          <p style={{ fontSize: 12, color: '#94a3b8', marginBottom: 4 }}>Home / Teachers</p>
          <h2 style={{ fontSize: 22, fontWeight: 700, color: '#0f172a' }}>Teachers</h2>
          <p style={{ fontSize: 13, color: '#94a3b8', marginTop: 4 }}>{teachers.length} teachers registered</p>
        </div>
        <button onClick={() => setShowForm(!showForm)}
          style={{ padding: '10px 20px', background: '#4f46e5', color: '#fff', border: 'none', borderRadius: 8, fontSize: 13, fontWeight: 600, cursor: 'pointer' }}>
          + Add Teacher
        </button>
      </div>

      {/* Add Form */}
      {showForm && (
        <div style={{ background: '#fff', borderRadius: 12, padding: 24, marginBottom: 24, boxShadow: '0 1px 3px rgba(0,0,0,0.06)', border: '1px solid #f1f5f9' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
            <h3 style={{ fontSize: 15, fontWeight: 700, color: '#0f172a' }}>Add New Teacher</h3>
            <button onClick={() => setShowForm(false)}
              style={{ width: 28, height: 28, background: '#f1f5f9', border: 'none', borderRadius: 6, cursor: 'pointer', fontSize: 14, color: '#64748b' }}>
              x
            </button>
          </div>
          <form onSubmit={handleSubmit}>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginBottom: 16 }}>
              <div>
                <label style={labelStyle}>Full Name</label>
                <input name="name" placeholder="e.g. Dr. Sharma" value={form.name} onChange={handleChange} style={inputStyle} required />
              </div>
              <div>
                <label style={labelStyle}>Email</label>
                <input name="email" type="email" placeholder="e.g. sharma@school.com" value={form.email} onChange={handleChange} style={inputStyle} required />
              </div>
              <div>
                <label style={labelStyle}>Password</label>
                <input name="password" type="password" placeholder="Set password" value={form.password} onChange={handleChange} style={inputStyle} required />
              </div>
              <div>
                <label style={labelStyle}>Role</label>
                <select name="role" value={form.role} onChange={handleChange} style={inputStyle}>
                  <option value="teacher">Teacher</option>
                  <option value="admin">Admin</option>
                </select>
              </div>
            </div>
            <div style={{ display: 'flex', gap: 10, justifyContent: 'flex-end' }}>
              <button type="button" onClick={() => setShowForm(false)}
                style={{ padding: '9px 20px', background: '#f1f5f9', color: '#64748b', border: 'none', borderRadius: 8, cursor: 'pointer', fontSize: 13, fontWeight: 500 }}>
                Cancel
              </button>
              <button type="submit" disabled={loading}
                style={{ padding: '9px 24px', background: '#4f46e5', color: '#fff', border: 'none', borderRadius: 8, cursor: 'pointer', fontSize: 13, fontWeight: 600 }}>
                {loading ? 'Saving...' : 'Add Teacher'}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Teachers Table */}
      <div style={{ background: '#fff', borderRadius: 12, boxShadow: '0 1px 3px rgba(0,0,0,0.06)', overflow: 'hidden' }}>
        <table style={{ width: '100%', borderCollapse: 'collapse' }}>
          <thead>
            <tr style={{ borderBottom: '1px solid #f1f5f9', background: '#fafafa' }}>
              <th style={{ padding: '12px 20px', textAlign: 'left', fontSize: 11, color: '#94a3b8', fontWeight: 600, textTransform: 'uppercase', letterSpacing: 0.5 }}>Teacher</th>
              <th style={{ padding: '12px 20px', textAlign: 'left', fontSize: 11, color: '#94a3b8', fontWeight: 600, textTransform: 'uppercase', letterSpacing: 0.5 }}>Email</th>
              <th style={{ padding: '12px 20px', textAlign: 'left', fontSize: 11, color: '#94a3b8', fontWeight: 600, textTransform: 'uppercase', letterSpacing: 0.5 }}>Role</th>
              <th style={{ padding: '12px 20px', textAlign: 'left', fontSize: 11, color: '#94a3b8', fontWeight: 600, textTransform: 'uppercase', letterSpacing: 0.5 }}>Status</th>
            </tr>
          </thead>
          <tbody>
            {teachers.map((t, i) => (
              <tr key={i} style={{ borderBottom: '1px solid #f8fafc' }}>
                <td style={{ padding: '14px 20px' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                    <div style={{ width: 34, height: 34, background: `${deptColors[i % deptColors.length]}15`, borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 13, fontWeight: 700, color: deptColors[i % deptColors.length], flexShrink: 0 }}>
                      {t.name?.charAt(0)}
                    </div>
                    <div>
                      <div style={{ fontWeight: 500, fontSize: 13, color: '#0f172a' }}>{t.name}</div>
                    </div>
                  </div>
                </td>
                <td style={{ padding: '14px 20px', fontSize: 13, color: '#64748b' }}>{t.email}</td>
                <td style={{ padding: '14px 20px' }}>
                  <span style={{ background: '#ede9fe', color: '#4f46e5', padding: '3px 10px', borderRadius: 6, fontSize: 12, fontWeight: 600, textTransform: 'capitalize' }}>
                    {t.role}
                  </span>
                </td>
                <td style={{ padding: '14px 20px' }}>
                  <span style={{ background: '#dcfce7', color: '#15803d', padding: '3px 10px', borderRadius: 999, fontSize: 11, fontWeight: 600 }}>
                    Active
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {teachers.length === 0 && (
          <div style={{ textAlign: 'center', padding: 60, color: '#94a3b8' }}>
            <p style={{ fontSize: 16, fontWeight: 500, marginBottom: 6 }}>No teachers yet</p>
            <p style={{ fontSize: 13 }}>Click Add Teacher to get started</p>
          </div>
        )}
      </div>
    </div>
  )
}