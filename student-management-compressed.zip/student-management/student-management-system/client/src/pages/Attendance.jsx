import { useEffect, useState } from 'react'
import { getStudents } from '../services/api'
import { useNotification } from '../context/NotificationContext'

export default function Attendance() {
  const [students,   setStudents]   = useState([])
  const [attendance, setAttendance] = useState({})
  const [date,       setDate]       = useState(new Date().toISOString().split('T')[0])
  const [search,     setSearch]     = useState('')
  const [filter,     setFilter]     = useState('all')
  const { addNotification } = useNotification()

  useEffect(() => {
    getStudents().then(r => {
      setStudents(r.data)
      const initial = {}
      r.data.forEach(s => initial[s._id] = 'present')
      setAttendance(initial)
    }).catch(() => {})
  }, [])

  const toggle  = (id, value) => setAttendance(prev => ({ ...prev, [id]: value }))

  const markAll = (value) => {
    const updated = {}
    students.forEach(s => updated[s._id] = value)
    setAttendance(updated)
    addNotification(`All students marked as ${value}!`, 'success')
  }

  const handleSave = () => addNotification('Attendance saved successfully!', 'success')

  const presentCount = Object.values(attendance).filter(v => v === 'present').length
  const absentCount  = Object.values(attendance).filter(v => v === 'absent').length
  const total        = students.length
  const pct          = total ? Math.round((presentCount / total) * 100) : 0

  const filtered = students.filter(s => {
    const matchSearch = s.name.toLowerCase().includes(search.toLowerCase()) ||
                        s.rollNumber.toLowerCase().includes(search.toLowerCase())
    const matchFilter = filter === 'all' ? true :
                        filter === 'present' ? attendance[s._id] === 'present' :
                        attendance[s._id] === 'absent'
    return matchSearch && matchFilter
  })

  return (
    <div className="fade-in" style={{ maxWidth: 1000, margin: '0 auto' }}>

      {/* Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 28 }}>
        <div>
          <p style={{ fontSize: 12, color: '#94a3b8', marginBottom: 4 }}>Home / Attendance</p>
          <h2 style={{ fontSize: 22, fontWeight: 700, color: '#0f172a' }}>Attendance</h2>
          <p style={{ fontSize: 13, color: '#94a3b8', marginTop: 4 }}>Mark and track student attendance</p>
        </div>
        <input type="date" value={date} onChange={e => setDate(e.target.value)}
          style={{ padding: '9px 14px', border: '1.5px solid #e2e8f0', borderRadius: 8, fontSize: 13, outline: 'none' }} />
      </div>

      {/* Stats */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 16, marginBottom: 24 }}>
        {[
          { label: 'Total',    value: total,         color: '#4f46e5' },
          { label: 'Present',  value: presentCount,  color: '#15803d' },
          { label: 'Absent',   value: absentCount,   color: '#dc2626' },
          { label: 'Rate',     value: `${pct}%`,     color: '#0369a1' },
        ].map(card => (
          <div key={card.label} style={{ background: '#fff', borderRadius: 12, padding: '18px 20px', boxShadow: '0 1px 3px rgba(0,0,0,0.06)', borderTop: `3px solid ${card.color}` }}>
            <p style={{ fontSize: 11, color: '#94a3b8', marginBottom: 8, fontWeight: 600, textTransform: 'uppercase', letterSpacing: 0.4 }}>{card.label}</p>
            <p style={{ fontSize: 28, fontWeight: 800, color: card.color }}>{card.value}</p>
          </div>
        ))}
      </div>

      {/* Progress */}
      <div style={{ background: '#fff', borderRadius: 12, padding: '16px 20px', marginBottom: 20, boxShadow: '0 1px 3px rgba(0,0,0,0.06)' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
          <span style={{ fontSize: 13, fontWeight: 600, color: '#0f172a' }}>Attendance Rate</span>
          <span style={{ fontSize: 13, fontWeight: 700, color: pct >= 75 ? '#15803d' : '#dc2626' }}>{pct}%</span>
        </div>
        <div style={{ background: '#f1f5f9', borderRadius: 999, height: 8 }}>
          <div style={{ width: `${pct}%`, background: pct >= 75 ? '#15803d' : '#dc2626', borderRadius: 999, height: 8, transition: 'width 1s ease' }} />
        </div>
      </div>

      {/* Controls */}
      <div style={{ background: '#fff', borderRadius: 12, padding: '14px 20px', marginBottom: 16, boxShadow: '0 1px 3px rgba(0,0,0,0.06)', display: 'flex', gap: 12, alignItems: 'center', flexWrap: 'wrap' }}>
        <input placeholder="Search students..." value={search} onChange={e => setSearch(e.target.value)}
          style={{ flex: 1, minWidth: 180, padding: '8px 14px', border: '1.5px solid #e2e8f0', borderRadius: 8, fontSize: 13, outline: 'none' }} />
        <div style={{ display: 'flex', gap: 4, background: '#f8fafc', borderRadius: 8, padding: 3, border: '1px solid #e2e8f0' }}>
          {['all', 'present', 'absent'].map(f => (
            <button key={f} onClick={() => setFilter(f)}
              style={{ padding: '5px 14px', background: filter === f ? '#fff' : 'transparent', border: 'none', borderRadius: 6, cursor: 'pointer', fontSize: 12, fontWeight: filter === f ? 600 : 400, color: filter === f ? '#4f46e5' : '#94a3b8', boxShadow: filter === f ? '0 1px 2px rgba(0,0,0,0.08)' : 'none', textTransform: 'capitalize' }}>
              {f}
            </button>
          ))}
        </div>
        <button onClick={() => markAll('present')}
          style={{ padding: '8px 16px', background: '#dcfce7', color: '#15803d', border: 'none', borderRadius: 8, cursor: 'pointer', fontSize: 12, fontWeight: 600 }}>
          Mark All Present
        </button>
        <button onClick={() => markAll('absent')}
          style={{ padding: '8px 16px', background: '#fee2e2', color: '#dc2626', border: 'none', borderRadius: 8, cursor: 'pointer', fontSize: 12, fontWeight: 600 }}>
          Mark All Absent
        </button>
      </div>

      {/* Table */}
      <div style={{ background: '#fff', borderRadius: 12, boxShadow: '0 1px 3px rgba(0,0,0,0.06)', overflow: 'hidden', marginBottom: 20 }}>
        <table style={{ width: '100%', borderCollapse: 'collapse' }}>
          <thead>
            <tr style={{ borderBottom: '1px solid #f1f5f9', background: '#fafafa' }}>
              <th style={{ padding: '12px 20px', textAlign: 'left', fontSize: 11, color: '#94a3b8', fontWeight: 600, textTransform: 'uppercase', letterSpacing: 0.5 }}>#</th>
              <th style={{ padding: '12px 20px', textAlign: 'left', fontSize: 11, color: '#94a3b8', fontWeight: 600, textTransform: 'uppercase', letterSpacing: 0.5 }}>Student</th>
              <th style={{ padding: '12px 20px', textAlign: 'left', fontSize: 11, color: '#94a3b8', fontWeight: 600, textTransform: 'uppercase', letterSpacing: 0.5 }}>Roll No</th>
              <th style={{ padding: '12px 20px', textAlign: 'left', fontSize: 11, color: '#94a3b8', fontWeight: 600, textTransform: 'uppercase', letterSpacing: 0.5 }}>Department</th>
              <th style={{ padding: '12px 20px', textAlign: 'left', fontSize: 11, color: '#94a3b8', fontWeight: 600, textTransform: 'uppercase', letterSpacing: 0.5 }}>Status</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((s, i) => (
              <tr key={s._id} style={{ borderBottom: '1px solid #f8fafc' }}>
                <td style={{ padding: '13px 20px', fontSize: 12, color: '#94a3b8' }}>{i + 1}</td>
                <td style={{ padding: '13px 20px' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                    <div style={{ width: 30, height: 30, background: attendance[s._id] === 'present' ? '#dcfce7' : '#fee2e2', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 12, fontWeight: 700, color: attendance[s._id] === 'present' ? '#15803d' : '#dc2626', flexShrink: 0 }}>
                      {s.name.charAt(0)}
                    </div>
                    <span style={{ fontSize: 13, fontWeight: 500, color: '#0f172a' }}>{s.name}</span>
                  </div>
                </td>
                <td style={{ padding: '13px 20px', fontSize: 13, color: '#64748b' }}>{s.rollNumber}</td>
                <td style={{ padding: '13px 20px', fontSize: 13, color: '#64748b' }}>{s.department}</td>
                <td style={{ padding: '13px 20px' }}>
                  <div style={{ display: 'flex', gap: 6 }}>
                    <button onClick={() => toggle(s._id, 'present')}
                      style={{ padding: '5px 14px', borderRadius: 6, border: 'none', cursor: 'pointer', fontSize: 12, fontWeight: 600, background: attendance[s._id] === 'present' ? '#15803d' : '#f1f5f9', color: attendance[s._id] === 'present' ? '#fff' : '#64748b', transition: 'all 0.15s' }}>
                      Present
                    </button>
                    <button onClick={() => toggle(s._id, 'absent')}
                      style={{ padding: '5px 14px', borderRadius: 6, border: 'none', cursor: 'pointer', fontSize: 12, fontWeight: 600, background: attendance[s._id] === 'absent' ? '#dc2626' : '#f1f5f9', color: attendance[s._id] === 'absent' ? '#fff' : '#64748b', transition: 'all 0.15s' }}>
                      Absent
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {students.length === 0 && (
          <div style={{ textAlign: 'center', padding: 60, color: '#94a3b8' }}>
            <p style={{ fontSize: 16, fontWeight: 500, marginBottom: 6 }}>No students found</p>
            <p style={{ fontSize: 13 }}>Add students first to mark attendance</p>
          </div>
        )}
      </div>

      <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
        <button onClick={handleSave}
          style={{ padding: '11px 28px', background: '#4f46e5', color: '#fff', border: 'none', borderRadius: 8, cursor: 'pointer', fontSize: 14, fontWeight: 600 }}>
          Save Attendance
        </button>
      </div>
    </div>
  )
}