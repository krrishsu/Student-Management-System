import { useEffect, useState } from 'react'
import { getStudents, getCourses } from '../services/api'
import { useAuth } from '../context/AuthContext'

export default function Dashboard() {
  const [students, setStudents] = useState([])
  const [courses,  setCourses]  = useState([])
  const { user } = useAuth()

  useEffect(() => {
    getStudents().then(r => setStudents(r.data)).catch(() => {})
    getCourses().then(r  => setCourses(r.data)).catch(() => {})
  }, [])

  const departments = [...new Set(students.map(s => s.department))]

  const greeting = () => {
    const h = new Date().getHours()
    if (h < 12) return 'Good Morning'
    if (h < 17) return 'Good Afternoon'
    return 'Good Evening'
  }

  const cards = [
    { label: 'Total Students',  value: students.length,                                   color: '#4f46e5' },
    { label: 'Total Courses',   value: courses.length,                                    color: '#0369a1' },
    { label: 'Departments',     value: departments.length,                                color: '#15803d' },
    { label: 'Active Students', value: students.filter(s => s.isActive !== false).length, color: '#7c3aed' },
  ]

  return (
    <div className="fade-in" style={{ maxWidth: 1000, margin: '0 auto' }}>

      {/* Welcome */}
      <div style={{ marginBottom: 32 }}>
        <p style={{ fontSize: 13, color: '#94a3b8', marginBottom: 4 }}>{greeting()}</p>
        <h2 style={{ fontSize: 26, fontWeight: 700, color: '#0f172a' }}>{user?.name}</h2>
        <p style={{ fontSize: 13, color: '#94a3b8', marginTop: 4 }}>
          {new Date().toLocaleDateString('en-IN', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
        </p>
      </div>

      {/* Stats */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 16, marginBottom: 32 }}>
        {cards.map(card => (
          <div key={card.label} style={{ background: '#fff', borderRadius: 12, padding: '20px 24px', boxShadow: '0 1px 3px rgba(0,0,0,0.06)', borderTop: `3px solid ${card.color}` }}>
            <p style={{ fontSize: 12, color: '#94a3b8', marginBottom: 10, fontWeight: 500, textTransform: 'uppercase', letterSpacing: 0.5 }}>{card.label}</p>
            <p style={{ fontSize: 36, fontWeight: 800, color: card.color }}>{card.value}</p>
          </div>
        ))}
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: 20 }}>

        {/* Recent Students */}
        <div style={{ background: '#fff', borderRadius: 12, padding: 24, boxShadow: '0 1px 3px rgba(0,0,0,0.06)' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
            <h3 style={{ fontSize: 15, fontWeight: 700, color: '#0f172a' }}>Recent Students</h3>
            <a href="/students" style={{ fontSize: 12, color: '#4f46e5', fontWeight: 600 }}>View all</a>
          </div>
          {students.length === 0 ? (
            <p style={{ color: '#94a3b8', textAlign: 'center', padding: 32, fontSize: 14 }}>No students yet</p>
          ) : (
            <table style={{ width: '100%', borderCollapse: 'collapse' }}>
              <thead>
                <tr style={{ borderBottom: '1px solid #f1f5f9' }}>
                  <th style={{ padding: '8px 0', textAlign: 'left', fontSize: 11, color: '#94a3b8', fontWeight: 600, textTransform: 'uppercase', letterSpacing: 0.5 }}>Name</th>
                  <th style={{ padding: '8px 0', textAlign: 'left', fontSize: 11, color: '#94a3b8', fontWeight: 600, textTransform: 'uppercase', letterSpacing: 0.5 }}>Department</th>
                  <th style={{ padding: '8px 0', textAlign: 'left', fontSize: 11, color: '#94a3b8', fontWeight: 600, textTransform: 'uppercase', letterSpacing: 0.5 }}>Year</th>
                  <th style={{ padding: '8px 0', textAlign: 'left', fontSize: 11, color: '#94a3b8', fontWeight: 600, textTransform: 'uppercase', letterSpacing: 0.5 }}>Status</th>
                </tr>
              </thead>
              <tbody>
                {students.slice(0, 5).map(s => (
                  <tr key={s._id} style={{ borderBottom: '1px solid #f8fafc' }}>
                    <td style={{ padding: '12px 0' }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                        <div style={{ width: 30, height: 30, background: '#ede9fe', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 12, fontWeight: 700, color: '#4f46e5', flexShrink: 0 }}>
                          {s.name.charAt(0)}
                        </div>
                        <div>
                          <div style={{ fontWeight: 500, fontSize: 13, color: '#0f172a' }}>{s.name}</div>
                          <div style={{ fontSize: 11, color: '#94a3b8' }}>{s.rollNumber}</div>
                        </div>
                      </div>
                    </td>
                    <td style={{ color: '#64748b', fontSize: 13, padding: '12px 0' }}>{s.department}</td>
                    <td style={{ color: '#64748b', fontSize: 13, padding: '12px 0' }}>Year {s.year}</td>
                    <td style={{ padding: '12px 0' }}>
                      <span style={{ background: '#dcfce7', color: '#15803d', padding: '2px 10px', borderRadius: 999, fontSize: 11, fontWeight: 600 }}>Active</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>

        {/* Quick Actions */}
        <div style={{ background: '#fff', borderRadius: 12, padding: 24, boxShadow: '0 1px 3px rgba(0,0,0,0.06)' }}>
          <h3 style={{ fontSize: 15, fontWeight: 700, color: '#0f172a', marginBottom: 20 }}>Quick Actions</h3>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {[
              { label: 'Add New Student',    path: '/students',   color: '#4f46e5' },
              { label: 'Add Course',         path: '/courses',    color: '#0369a1' },
              { label: 'Mark Attendance',    path: '/attendance', color: '#15803d' },
              { label: 'Manage Fees',        path: '/fees',       color: '#a16207' },
              { label: 'Add Grades',         path: '/grades',     color: '#7c3aed' },
              { label: 'Manage Teachers',    path: '/teachers',   color: '#0e7490' },
            ].map(item => (
              <a key={item.label} href={item.path} style={{
                padding: '11px 16px',
                background: '#f8fafc',
                borderRadius: 8,
                fontSize: 13,
                fontWeight: 500,
                color: '#334155',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                border: '1px solid #f1f5f9',
                transition: 'all 0.15s'
              }}>
                {item.label}
                <span style={{ color: item.color, fontWeight: 700, fontSize: 16 }}>→</span>
              </a>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}