import { useEffect, useState } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { getStudents } from '../services/api'

export default function StudentProfile() {
  const { id }     = useParams()
  const navigate   = useNavigate()
  const [student, setStudent] = useState(null)

  useEffect(() => {
    getStudents().then(r => {
      const found = r.data.find(s => s._id === id)
      setStudent(found)
    }).catch(() => {})
  }, [id])

  if (!student) return (
    <div style={{ textAlign: 'center', padding: 60, color: '#94a3b8' }}>
      <p style={{ fontSize: 16, fontWeight: 500 }}>Loading student profile...</p>
    </div>
  )

  const deptColors = ['#4f46e5', '#0369a1', '#15803d', '#a16207', '#dc2626']
  const idx        = student.name.charCodeAt(0) % deptColors.length
  const color      = deptColors[idx]

  const info = [
    { label: 'Roll Number', value: student.rollNumber },
    { label: 'Email',       value: student.email      },
    { label: 'Phone',       value: student.phone || 'Not provided' },
    { label: 'Department',  value: student.department },
    { label: 'Year',        value: `Year ${student.year}` },
    { label: 'Status',      value: 'Active' },
  ]

  return (
    <div className="fade-in" style={{ maxWidth: 860, margin: '0 auto' }}>

      {/* Back */}
      <button onClick={() => navigate('/students')}
        style={{ marginBottom: 20, padding: '7px 16px', background: '#f1f5f9', border: 'none', borderRadius: 8, cursor: 'pointer', fontSize: 13, fontWeight: 500, color: '#64748b' }}>
        Back to Students
      </button>

      {/* Profile Header */}
      <div style={{ background: '#fff', borderRadius: 12, overflow: 'hidden', boxShadow: '0 1px 3px rgba(0,0,0,0.06)', marginBottom: 20 }}>
        <div style={{ height: 100, background: `linear-gradient(135deg, ${color}22, ${color}44)`, borderBottom: `3px solid ${color}` }} />
        <div style={{ padding: '0 24px 24px', marginTop: -32 }}>
          <div style={{ display: 'flex', alignItems: 'flex-end', gap: 16, marginBottom: 16 }}>
            <div style={{ width: 64, height: 64, background: color, borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', fontWeight: 800, fontSize: 24, border: '3px solid #fff', boxShadow: '0 2px 8px rgba(0,0,0,0.12)', flexShrink: 0 }}>
              {student.name.charAt(0)}
            </div>
            <div style={{ paddingBottom: 4 }}>
              <h2 style={{ fontSize: 20, fontWeight: 700, color: '#0f172a', marginBottom: 4 }}>{student.name}</h2>
              <p style={{ fontSize: 13, color: '#94a3b8' }}>{student.email}</p>
            </div>
          </div>
          <div style={{ display: 'flex', gap: 8 }}>
            <span style={{ fontSize: 12, background: '#dcfce7', color: '#15803d', padding: '3px 12px', borderRadius: 999, fontWeight: 600 }}>Active</span>
            <span style={{ fontSize: 12, background: '#ede9fe', color: '#4f46e5', padding: '3px 12px', borderRadius: 999, fontWeight: 600 }}>{student.department}</span>
            <span style={{ fontSize: 12, background: '#e0f2fe', color: '#0369a1', padding: '3px 12px', borderRadius: 999, fontWeight: 600 }}>Year {student.year}</span>
          </div>
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20 }}>

        {/* Info */}
        <div style={{ background: '#fff', borderRadius: 12, padding: 24, boxShadow: '0 1px 3px rgba(0,0,0,0.06)' }}>
          <h3 style={{ fontSize: 14, fontWeight: 700, color: '#0f172a', marginBottom: 16, textTransform: 'uppercase', letterSpacing: 0.5, fontSize: 12, color: '#94a3b8' }}>Student Information</h3>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 0 }}>
            {info.map((item, i) => (
              <div key={item.label} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '12px 0', borderBottom: i < info.length - 1 ? '1px solid #f8fafc' : 'none' }}>
                <span style={{ fontSize: 12, color: '#94a3b8', fontWeight: 500 }}>{item.label}</span>
                <span style={{ fontSize: 13, fontWeight: 500, color: '#0f172a' }}>{item.value}</span>
              </div>
            ))}
          </div>
        </div>

        {/* ID Card */}
        <div style={{ background: '#fff', borderRadius: 12, padding: 24, boxShadow: '0 1px 3px rgba(0,0,0,0.06)' }}>
          <p style={{ fontSize: 12, fontWeight: 600, color: '#94a3b8', marginBottom: 16, textTransform: 'uppercase', letterSpacing: 0.5 }}>Student ID Card</p>

          <div style={{ background: `linear-gradient(135deg, #1a1a2e, #16213e)`, borderRadius: 12, padding: 20, marginBottom: 16, border: `1px solid ${color}33` }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 16 }}>
              <div>
                <p style={{ fontSize: 9, color: 'rgba(255,255,255,0.4)', letterSpacing: 1, marginBottom: 2 }}>STUDENT ID</p>
                <p style={{ fontSize: 14, fontWeight: 700, color: '#fff' }}>SMS University</p>
              </div>
              <div style={{ width: 28, height: 28, background: color, borderRadius: 6, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <span style={{ color: '#fff', fontWeight: 800, fontSize: 12 }}>S</span>
              </div>
            </div>
            <div style={{ width: 44, height: 44, background: color, borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: 12 }}>
              <span style={{ color: '#fff', fontWeight: 800, fontSize: 18 }}>{student.name.charAt(0)}</span>
            </div>
            <p style={{ fontSize: 16, fontWeight: 700, color: '#fff', marginBottom: 2 }}>{student.name}</p>
            <p style={{ fontSize: 11, color: 'rgba(255,255,255,0.6)', marginBottom: 2 }}>{student.rollNumber}</p>
            <p style={{ fontSize: 11, color: 'rgba(255,255,255,0.6)', marginBottom: 2 }}>{student.department}</p>
            <p style={{ fontSize: 11, color: 'rgba(255,255,255,0.6)', marginBottom: 16 }}>Year {student.year}</p>
            <div style={{ borderTop: '1px solid rgba(255,255,255,0.1)', paddingTop: 10, display: 'flex', justifyContent: 'space-between' }}>
              <p style={{ fontSize: 10, color: 'rgba(255,255,255,0.4)' }}>Valid: 2024-2025</p>
              <p style={{ fontSize: 10, color: 'rgba(255,255,255,0.4)' }}>SMS University</p>
            </div>
          </div>

          <button onClick={() => window.print()}
            style={{ width: '100%', padding: '10px', background: '#4f46e5', color: '#fff', border: 'none', borderRadius: 8, cursor: 'pointer', fontSize: 13, fontWeight: 600 }}>
            Print ID Card
          </button>
        </div>
      </div>

      {/* Courses */}
      <div style={{ background: '#fff', borderRadius: 12, padding: 24, boxShadow: '0 1px 3px rgba(0,0,0,0.06)', marginTop: 20 }}>
        <p style={{ fontSize: 12, fontWeight: 600, color: '#94a3b8', marginBottom: 16, textTransform: 'uppercase', letterSpacing: 0.5 }}>Enrolled Courses</p>
        {student.courses && student.courses.length > 0 ? (
          <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
            {student.courses.map((c, i) => (
              <span key={i} style={{ background: '#f1f5f9', color: '#4f46e5', padding: '6px 14px', borderRadius: 8, fontSize: 13, fontWeight: 500 }}>
                {c.name || c}
              </span>
            ))}
          </div>
        ) : (
          <p style={{ color: '#94a3b8', fontSize: 13 }}>No courses enrolled yet</p>
        )}
      </div>
    </div>
  )
}