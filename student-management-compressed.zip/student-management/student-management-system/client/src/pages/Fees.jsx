import { useEffect, useState } from 'react'
import { getStudents } from '../services/api'
import { useNotification } from '../context/NotificationContext'

export default function Fees() {
  const [students, setStudents] = useState([])
  const [fees,     setFees]     = useState({})
  const [search,   setSearch]   = useState('')
  const [filter,   setFilter]   = useState('all')
  const { addNotification } = useNotification()

  useEffect(() => {
    getStudents().then(r => {
      setStudents(r.data)
      const initial = {}
      r.data.forEach(s => {
        initial[s._id] = { total: 50000, paid: 0, status: 'unpaid' }
      })
      setFees(initial)
    }).catch(() => {})
  }, [])

  const handlePay = (id, amount) => {
    setFees(prev => {
      const current = prev[id]
      const newPaid = Math.min(current.paid + Number(amount), current.total)
      const status  = newPaid >= current.total ? 'paid' : newPaid > 0 ? 'partial' : 'unpaid'
      return { ...prev, [id]: { ...current, paid: newPaid, status } }
    })
    addNotification(`Payment of Rs.${amount.toLocaleString()} recorded!`, 'success')
  }

  const totalFees      = students.length * 50000
  const totalCollected = Object.values(fees).reduce((sum, f) => sum + f.paid, 0)
  const totalPending   = totalFees - totalCollected
  const paidCount      = Object.values(fees).filter(f => f.status === 'paid').length
  const unpaidCount    = Object.values(fees).filter(f => f.status === 'unpaid').length
  const partialCount   = Object.values(fees).filter(f => f.status === 'partial').length
  const collectionPct  = totalFees ? Math.round((totalCollected / totalFees) * 100) : 0

  const filtered = students.filter(s => {
    const matchSearch = s.name.toLowerCase().includes(search.toLowerCase()) ||
                        s.rollNumber.toLowerCase().includes(search.toLowerCase())
    const matchFilter = filter === 'all' ? true : fees[s._id]?.status === filter
    return matchSearch && matchFilter
  })

  const statusConfig = {
    paid:    { color: '#15803d', bg: '#dcfce7', label: 'Paid'    },
    partial: { color: '#a16207', bg: '#fef9c3', label: 'Partial' },
    unpaid:  { color: '#dc2626', bg: '#fee2e2', label: 'Unpaid'  },
  }

  return (
    <div className="fade-in" style={{ maxWidth: 1100, margin: '0 auto' }}>

      {/* Header */}
      <div style={{ marginBottom: 28 }}>
        <p style={{ fontSize: 12, color: '#94a3b8', marginBottom: 4 }}>Home / Fees</p>
        <h2 style={{ fontSize: 22, fontWeight: 700, color: '#0f172a' }}>Fee Management</h2>
        <p style={{ fontSize: 13, color: '#94a3b8', marginTop: 4 }}>Track and manage student fee payments</p>
      </div>

      {/* Stats */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 16, marginBottom: 24 }}>
        {[
          { label: 'Total Fees',  value: `Rs.${totalFees.toLocaleString()}`,      color: '#4f46e5' },
          { label: 'Collected',   value: `Rs.${totalCollected.toLocaleString()}`, color: '#15803d' },
          { label: 'Pending',     value: `Rs.${totalPending.toLocaleString()}`,   color: '#dc2626' },
        ].map(card => (
          <div key={card.label} style={{ background: '#fff', borderRadius: 12, padding: '18px 20px', boxShadow: '0 1px 3px rgba(0,0,0,0.06)', borderTop: `3px solid ${card.color}` }}>
            <p style={{ fontSize: 11, color: '#94a3b8', marginBottom: 8, fontWeight: 600, textTransform: 'uppercase', letterSpacing: 0.4 }}>{card.label}</p>
            <p style={{ fontSize: 24, fontWeight: 800, color: card.color }}>{card.value}</p>
          </div>
        ))}
      </div>

      {/* Collection Progress */}
      <div style={{ background: '#fff', borderRadius: 12, padding: '18px 24px', marginBottom: 20, boxShadow: '0 1px 3px rgba(0,0,0,0.06)' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
          <div>
            <h3 style={{ fontSize: 14, fontWeight: 700, color: '#0f172a', marginBottom: 2 }}>Collection Progress</h3>
            <p style={{ fontSize: 12, color: '#94a3b8' }}>
              {paidCount} fully paid · {partialCount} partial · {unpaidCount} unpaid
            </p>
          </div>
          <span style={{ fontSize: 22, fontWeight: 800, color: '#4f46e5' }}>{collectionPct}%</span>
        </div>
        <div style={{ background: '#f1f5f9', borderRadius: 999, height: 10 }}>
          <div style={{ width: `${collectionPct}%`, background: '#4f46e5', borderRadius: 999, height: 10, transition: 'width 1s ease' }} />
        </div>
      </div>

      {/* Filters */}
      <div style={{ background: '#fff', borderRadius: 12, padding: '14px 20px', marginBottom: 16, boxShadow: '0 1px 3px rgba(0,0,0,0.06)', display: 'flex', gap: 12, alignItems: 'center', flexWrap: 'wrap' }}>
        <input placeholder="Search students..." value={search} onChange={e => setSearch(e.target.value)}
          style={{ flex: 1, minWidth: 180, padding: '8px 14px', border: '1.5px solid #e2e8f0', borderRadius: 8, fontSize: 13, outline: 'none' }} />
        <div style={{ display: 'flex', gap: 4, background: '#f8fafc', borderRadius: 8, padding: 3, border: '1px solid #e2e8f0' }}>
          {['all', 'paid', 'partial', 'unpaid'].map(f => (
            <button key={f} onClick={() => setFilter(f)}
              style={{ padding: '5px 14px', background: filter === f ? '#fff' : 'transparent', border: 'none', borderRadius: 6, cursor: 'pointer', fontSize: 12, fontWeight: filter === f ? 600 : 400, color: filter === f ? '#4f46e5' : '#94a3b8', boxShadow: filter === f ? '0 1px 2px rgba(0,0,0,0.08)' : 'none', textTransform: 'capitalize' }}>
              {f === 'all' ? 'All' : f.charAt(0).toUpperCase() + f.slice(1)}
            </button>
          ))}
        </div>
      </div>

      {/* Table */}
      <div style={{ background: '#fff', borderRadius: 12, boxShadow: '0 1px 3px rgba(0,0,0,0.06)', overflow: 'hidden' }}>
        <table style={{ width: '100%', borderCollapse: 'collapse' }}>
          <thead>
            <tr style={{ borderBottom: '1px solid #f1f5f9', background: '#fafafa' }}>
              <th style={{ padding: '12px 20px', textAlign: 'left', fontSize: 11, color: '#94a3b8', fontWeight: 600, textTransform: 'uppercase', letterSpacing: 0.5 }}>Student</th>
              <th style={{ padding: '12px 20px', textAlign: 'left', fontSize: 11, color: '#94a3b8', fontWeight: 600, textTransform: 'uppercase', letterSpacing: 0.5 }}>Total Fee</th>
              <th style={{ padding: '12px 20px', textAlign: 'left', fontSize: 11, color: '#94a3b8', fontWeight: 600, textTransform: 'uppercase', letterSpacing: 0.5 }}>Paid</th>
              <th style={{ padding: '12px 20px', textAlign: 'left', fontSize: 11, color: '#94a3b8', fontWeight: 600, textTransform: 'uppercase', letterSpacing: 0.5 }}>Pending</th>
              <th style={{ padding: '12px 20px', textAlign: 'left', fontSize: 11, color: '#94a3b8', fontWeight: 600, textTransform: 'uppercase', letterSpacing: 0.5 }}>Progress</th>
              <th style={{ padding: '12px 20px', textAlign: 'left', fontSize: 11, color: '#94a3b8', fontWeight: 600, textTransform: 'uppercase', letterSpacing: 0.5 }}>Status</th>
              <th style={{ padding: '12px 20px', textAlign: 'left', fontSize: 11, color: '#94a3b8', fontWeight: 600, textTransform: 'uppercase', letterSpacing: 0.5 }}>Action</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map(s => {
              const fee     = fees[s._id] || { total: 50000, paid: 0, status: 'unpaid' }
              const pending = fee.total - fee.paid
              const pct     = Math.round((fee.paid / fee.total) * 100)
              const sc      = statusConfig[fee.status]
              return (
                <tr key={s._id} style={{ borderBottom: '1px solid #f8fafc' }}>
                  <td style={{ padding: '14px 20px' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                      <div style={{ width: 32, height: 32, background: '#ede9fe', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 12, fontWeight: 700, color: '#4f46e5', flexShrink: 0 }}>
                        {s.name.charAt(0)}
                      </div>
                      <div>
                        <div style={{ fontWeight: 500, fontSize: 13, color: '#0f172a' }}>{s.name}</div>
                        <div style={{ fontSize: 11, color: '#94a3b8' }}>{s.department}</div>
                      </div>
                    </div>
                  </td>
                  <td style={{ padding: '14px 20px', fontSize: 13, fontWeight: 600, color: '#0f172a' }}>Rs.{fee.total.toLocaleString()}</td>
                  <td style={{ padding: '14px 20px', fontSize: 13, fontWeight: 600, color: '#15803d' }}>Rs.{fee.paid.toLocaleString()}</td>
                  <td style={{ padding: '14px 20px', fontSize: 13, fontWeight: 600, color: '#dc2626' }}>Rs.{pending.toLocaleString()}</td>
                  <td style={{ padding: '14px 20px', minWidth: 120 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                      <div style={{ flex: 1, background: '#f1f5f9', borderRadius: 999, height: 6 }}>
                        <div style={{ width: `${pct}%`, background: '#4f46e5', borderRadius: 999, height: 6, transition: 'width 0.5s' }} />
                      </div>
                      <span style={{ fontSize: 11, color: '#94a3b8', minWidth: 28 }}>{pct}%</span>
                    </div>
                  </td>
                  <td style={{ padding: '14px 20px' }}>
                    <span style={{ fontSize: 11, background: sc.bg, color: sc.color, padding: '3px 10px', borderRadius: 999, fontWeight: 600 }}>
                      {sc.label}
                    </span>
                  </td>
                  <td style={{ padding: '14px 20px' }}>
                    {fee.status !== 'paid' ? (
                      <div style={{ display: 'flex', gap: 4 }}>
                        {[5000, 10000, 25000].map(amt => (
                          <button key={amt} onClick={() => handlePay(s._id, amt)}
                            style={{ padding: '4px 8px', background: '#ede9fe', color: '#4f46e5', border: 'none', borderRadius: 6, cursor: 'pointer', fontSize: 11, fontWeight: 600 }}>
                            +{amt/1000}k
                          </button>
                        ))}
                      </div>
                    ) : (
                      <span style={{ color: '#15803d', fontSize: 12, fontWeight: 600 }}>Cleared</span>
                    )}
                  </td>
                </tr>
              )
            })}
          </tbody>
        </table>
        {students.length === 0 && (
          <div style={{ textAlign: 'center', padding: 60, color: '#94a3b8' }}>
            <p style={{ fontSize: 16, fontWeight: 500, marginBottom: 6 }}>No students found</p>
            <p style={{ fontSize: 13 }}>Add students first to manage fees</p>
          </div>
        )}
      </div>
    </div>
  )
}


































































