import { useEffect, useState } from 'react'
import { getStudents, getCourses } from '../services/api'
import { useNotification } from '../context/NotificationContext'

export default function Grades() {
  const [students,        setStudents]        = useState([])
  const [courses,         setCourses]         = useState([])
  const [selectedStudent, setSelectedStudent] = useState('')
  const [selectedCourse,  setSelectedCourse]  = useState('')
  const [marks,           setMarks]           = useState('')
  const [grade,           setGrade]           = useState(null)
  const [savedGrades,     setSavedGrades]     = useState([])
  const { addNotification } = useNotification()

  useEffect(() => {
    getStudents().then(r => setStudents(r.data)).catch(() => {})
    getCourses().then(r  => setCourses(r.data)).catch(() => {})
  }, [])

  const getGradeInfo = (m) => {
    if (m >= 90) return { grade: 'A+', color: '#15803d', bg: '#dcfce7' }
    if (m >= 80) return { grade: 'A',  color: '#0369a1', bg: '#e0f2fe' }
    if (m >= 70) return { grade: 'B',  color: '#7c3aed', bg: '#ede9fe' }
    if (m >= 60) return { grade: 'C',  color: '#a16207', bg: '#fef9c3' }
    if (m >= 50) return { grade: 'D',  color: '#c2410c', bg: '#ffedd5' }
    return               { grade: 'F',  color: '#dc2626', bg: '#fee2e2' }
  }

  const handleMarksChange = (e) => {
    const val = e.target.value
    setMarks(val)
    setGrade(val ? getGradeInfo(Number(val)) : null)
  }

  const handleSave = () => {
    if (!selectedStudent || !selectedCourse || !marks) {
      addNotification('Please fill all fields!', 'error')
      return
    }
    const student   = students.find(s => s._id === selectedStudent)
    const course    = courses.find(c  => c._id === selectedCourse)
    const gradeInfo = getGradeInfo(Number(marks))
    setSavedGrades(prev => [...prev, {
      id:          Date.now(),
      studentName: student?.name,
      rollNumber:  student?.rollNumber,
      courseName:  course?.name,
      courseCode:  course?.code,
      marks:       Number(marks),
      grade:       gradeInfo.grade,
      color:       gradeInfo.color,
      bg:          gradeInfo.bg,
    }])
    setSelectedStudent(''); setSelectedCourse(''); setMarks(''); setGrade(null)
    addNotification('Grade saved successfully!', 'success')
  }

  const inputStyle = {
    width: '100%', padding: '10px 14px',
    border: '1.5px solid #e2e8f0', borderRadius: 8,
    fontSize: 13, boxSizing: 'border-box', outline: 'none',
    marginBottom: 16
  }

  const labelStyle = {
    fontSize: 12, fontWeight: 600, color: '#64748b',
    display: 'block', marginBottom: 6,
    textTransform: 'uppercase', letterSpacing: 0.4
  }

  const gradeScale = [
    { grade: 'A+', range: '90-100', color: '#15803d', bg: '#dcfce7' },
    { grade: 'A',  range: '80-89',  color: '#0369a1', bg: '#e0f2fe' },
    { grade: 'B',  range: '70-79',  color: '#7c3aed', bg: '#ede9fe' },
    { grade: 'C',  range: '60-69',  color: '#a16207', bg: '#fef9c3' },
    { grade: 'D',  range: '50-59',  color: '#c2410c', bg: '#ffedd5' },
    { grade: 'F',  range: '0-49',   color: '#dc2626', bg: '#fee2e2' },
  ]

  return (
    <div className="fade-in" style={{ maxWidth: 1000, margin: '0 auto' }}>

      {/* Header */}
      <div style={{ marginBottom: 28 }}>
        <p style={{ fontSize: 12, color: '#94a3b8', marginBottom: 4 }}>Home / Grades</p>
        <h2 style={{ fontSize: 22, fontWeight: 700, color: '#0f172a' }}>Grades</h2>
        <p style={{ fontSize: 13, color: '#94a3b8', marginTop: 4 }}>Assign and manage student grades</p>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20, marginBottom: 24 }}>

        {/* Add Grade */}
        <div style={{ background: '#fff', borderRadius: 12, padding: 24, boxShadow: '0 1px 3px rgba(0,0,0,0.06)' }}>
          <h3 style={{ fontSize: 15, fontWeight: 700, color: '#0f172a', marginBottom: 20 }}>Add Grade</h3>

          <label style={labelStyle}>Student</label>
          <select value={selectedStudent} onChange={e => setSelectedStudent(e.target.value)} style={inputStyle}>
            <option value="">Select Student</option>
            {students.map(s => <option key={s._id} value={s._id}>{s.name} ({s.rollNumber})</option>)}
          </select>

          <label style={labelStyle}>Course</label>
          <select value={selectedCourse} onChange={e => setSelectedCourse(e.target.value)} style={inputStyle}>
            <option value="">Select Course</option>
            {courses.map(c => <option key={c._id} value={c._id}>{c.name} ({c.code})</option>)}
          </select>

          <label style={labelStyle}>Marks (0-100)</label>
          <input type="number" min="0" max="100" placeholder="Enter marks"
            value={marks} onChange={handleMarksChange} style={inputStyle} />

          {grade && (
            <div style={{ background: grade.bg, borderRadius: 10, padding: '12px 16px', marginBottom: 16, display: 'flex', alignItems: 'center', gap: 14 }}>
              <div style={{ width: 44, height: 44, background: grade.color, borderRadius: 8, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <span style={{ color: '#fff', fontWeight: 800, fontSize: 18 }}>{grade.grade}</span>
              </div>
              <div>
                <p style={{ fontSize: 13, fontWeight: 600, color: grade.color }}>Grade: {grade.grade}</p>
                <p style={{ fontSize: 12, color: grade.color, opacity: 0.8 }}>Marks: {marks}/100</p>
              </div>
            </div>
          )}

          <button onClick={handleSave}
            style={{ width: '100%', padding: '11px', background: '#4f46e5', color: '#fff', border: 'none', borderRadius: 8, cursor: 'pointer', fontSize: 14, fontWeight: 600 }}>
            Save Grade
          </button>
        </div>

        {/* Grade Scale */}
        <div style={{ background: '#fff', borderRadius: 12, padding: 24, boxShadow: '0 1px 3px rgba(0,0,0,0.06)' }}>
          <h3 style={{ fontSize: 15, fontWeight: 700, color: '#0f172a', marginBottom: 20 }}>Grade Scale</h3>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {gradeScale.map(g => (
              <div key={g.grade} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', background: g.bg, borderRadius: 8, padding: '10px 14px' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                  <div style={{ width: 32, height: 32, background: g.color, borderRadius: 6, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                    <span style={{ color: '#fff', fontWeight: 800, fontSize: 13 }}>{g.grade}</span>
                  </div>
                  <span style={{ fontSize: 13, fontWeight: 500, color: g.color }}>Grade {g.grade}</span>
                </div>
                <span style={{ fontSize: 12, color: g.color, fontWeight: 600 }}>{g.range} marks</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Saved Grades Table */}
      <div style={{ background: '#fff', borderRadius: 12, boxShadow: '0 1px 3px rgba(0,0,0,0.06)', overflow: 'hidden' }}>
        <div style={{ padding: '16px 20px', borderBottom: '1px solid #f1f5f9' }}>
          <h3 style={{ fontSize: 15, fontWeight: 700, color: '#0f172a' }}>Grade Records</h3>
        </div>
        {savedGrades.length === 0 ? (
          <div style={{ textAlign: 'center', padding: 60, color: '#94a3b8' }}>
            <p style={{ fontSize: 16, fontWeight: 500, marginBottom: 6 }}>No grades added yet</p>
            <p style={{ fontSize: 13 }}>Use the form above to add grades</p>
          </div>
        ) : (
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr style={{ borderBottom: '1px solid #f1f5f9', background: '#fafafa' }}>
                <th style={{ padding: '12px 20px', textAlign: 'left', fontSize: 11, color: '#94a3b8', fontWeight: 600, textTransform: 'uppercase', letterSpacing: 0.5 }}>Student</th>
                <th style={{ padding: '12px 20px', textAlign: 'left', fontSize: 11, color: '#94a3b8', fontWeight: 600, textTransform: 'uppercase', letterSpacing: 0.5 }}>Course</th>
                <th style={{ padding: '12px 20px', textAlign: 'left', fontSize: 11, color: '#94a3b8', fontWeight: 600, textTransform: 'uppercase', letterSpacing: 0.5 }}>Marks</th>
                <th style={{ padding: '12px 20px', textAlign: 'left', fontSize: 11, color: '#94a3b8', fontWeight: 600, textTransform: 'uppercase', letterSpacing: 0.5 }}>Grade</th>
              </tr>
            </thead>
            <tbody>
              {savedGrades.map(g => (
                <tr key={g.id} style={{ borderBottom: '1px solid #f8fafc' }}>
                  <td style={{ padding: '13px 20px' }}>
                    <div style={{ fontWeight: 500, fontSize: 13, color: '#0f172a' }}>{g.studentName}</div>
                    <div style={{ fontSize: 11, color: '#94a3b8' }}>{g.rollNumber}</div>
                  </td>
                  <td style={{ padding: '13px 20px' }}>
                    <div style={{ fontSize: 13, color: '#0f172a' }}>{g.courseName}</div>
                    <div style={{ fontSize: 11, color: '#94a3b8' }}>{g.courseCode}</div>
                  </td>
                  <td style={{ padding: '13px 20px', fontSize: 13, fontWeight: 600, color: '#0f172a' }}>{g.marks}/100</td>
                  <td style={{ padding: '13px 20px' }}>
                    <span style={{ background: g.bg, color: g.color, padding: '4px 12px', borderRadius: 999, fontSize: 12, fontWeight: 700 }}>
                      {g.grade}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  )
}