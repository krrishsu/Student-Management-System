import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { loginUser } from '../services/api'
import { useAuth } from '../context/AuthContext'

const stats = [
  { label: 'Students Enrolled', value: '12,400+' },
  { label: 'Courses Available', value: '340+'    },
  { label: 'Faculty Members',   value: '280+'    },
  { label: 'Departments',       value: '24'      },
]

export default function Login() {
  const [email,    setEmail]    = useState('')
  const [password, setPassword] = useState('')
  const [error,    setError]    = useState('')
  const [loading,  setLoading]  = useState(false)
  const [showPass, setShowPass] = useState(false)
  const [time,     setTime]     = useState(new Date())
  const { login } = useAuth()
  const navigate  = useNavigate()

  useEffect(() => {
    const t = setInterval(() => setTime(new Date()), 1000)
    return () => clearInterval(t)
  }, [])

  const handleSubmit = async (e) => {
    e.preventDefault()
    setLoading(true)
    setError('')
    try {
      const { data } = await loginUser({ email, password })
      login(data)
      navigate('/')
    } catch {
      setError('Invalid email or password. Please try again.')
    }
    setLoading(false)
  }

  return (
    <div style={{ minHeight: '100vh', display: 'flex', fontFamily: "'Segoe UI', sans-serif" }}>

      {/* Left Panel */}
      <div style={{
        flex: 1.2,
        background: 'linear-gradient(160deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%)',
        display: 'flex', flexDirection: 'column',
        justifyContent: 'space-between',
        padding: 48, position: 'relative', overflow: 'hidden'
      }}>

        {/* Background circles */}
        <div style={{ position: 'absolute', top: -80, right: -80, width: 300, height: 300, borderRadius: '50%', background: 'rgba(79,70,229,0.15)', pointerEvents: 'none' }} />
        <div style={{ position: 'absolute', bottom: 100, left: -60, width: 200, height: 200, borderRadius: '50%', background: 'rgba(124,58,237,0.1)', pointerEvents: 'none' }} />

        {/* Top */}
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 48 }}>
            <div style={{ width: 44, height: 44, background: 'linear-gradient(135deg, #4f46e5, #7c3aed)', borderRadius: 10, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <span style={{ color: '#fff', fontWeight: 900, fontSize: 20 }}>S</span>
            </div>
            <div>
              <div style={{ color: '#fff', fontWeight: 800, fontSize: 18 }}>SMS Portal</div>
              <div style={{ color: 'rgba(255,255,255,0.5)', fontSize: 11 }}>Student Management System</div>
            </div>
          </div>

          {/* Live Clock */}
          <div style={{ marginBottom: 32 }}>
            <div style={{ color: 'rgba(255,255,255,0.4)', fontSize: 12, marginBottom: 4 }}>
              {time.toLocaleDateString('en-IN', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
            </div>
            <div style={{ color: '#fff', fontSize: 42, fontWeight: 200, letterSpacing: 2 }}>
              {time.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' })}
            </div>
          </div>

          <h1 style={{ color: '#fff', fontSize: 32, fontWeight: 700, lineHeight: 1.3, marginBottom: 16 }}>
            Welcome to the<br />
            <span style={{ color: '#818cf8' }}>Student Portal</span>
          </h1>
          <p style={{ color: 'rgba(255,255,255,0.6)', fontSize: 15, lineHeight: 1.7 }}>
            Your all-in-one platform for managing academics, attendance, grades, and fees.
          </p>
        </div>

        {/* Stats */}
        <div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginBottom: 32 }}>
            {stats.map(s => (
              <div key={s.label} style={{ background: 'rgba(255,255,255,0.06)', borderRadius: 12, padding: 16, border: '1px solid rgba(255,255,255,0.08)' }}>
                <div style={{ color: '#818cf8', fontSize: 22, fontWeight: 700, marginBottom: 4 }}>{s.value}</div>
                <div style={{ color: 'rgba(255,255,255,0.5)', fontSize: 12 }}>{s.label}</div>
              </div>
            ))}
          </div>
          <div style={{ display: 'flex', gap: 8 }}>
            {['Academics', 'Attendance', 'Grades', 'Fees', 'ID Cards'].map(tag => (
              <span key={tag} style={{ fontSize: 11, background: 'rgba(79,70,229,0.3)', color: '#a5b4fc', padding: '4px 10px', borderRadius: 999, border: '1px solid rgba(79,70,229,0.4)' }}>
                {tag}
              </span>
            ))}
          </div>
        </div>
      </div>

      {/* Right Panel */}
      <div style={{ flex: 1, background: '#fff', display: 'flex', flexDirection: 'column', justifyContent: 'center', padding: '48px 56px' }}>

        <div style={{ maxWidth: 380, width: '100%' }}>
          <div style={{ marginBottom: 36 }}>
            <h2 style={{ fontSize: 26, fontWeight: 700, color: '#0f172a', marginBottom: 8 }}>Sign in</h2>
            <p style={{ color: '#94a3b8', fontSize: 14 }}>Enter your credentials to access the portal</p>
          </div>

          {error && (
            <div style={{ background: '#fef2f2', border: '1px solid #fecaca', color: '#dc2626', padding: '12px 16px', borderRadius: 8, marginBottom: 20, fontSize: 13 }}>
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit}>
            <div style={{ marginBottom: 20 }}>
              <label style={{ fontSize: 13, fontWeight: 600, color: '#374151', display: 'block', marginBottom: 8 }}>
                Email Address
              </label>
              <input
                type="email"
                placeholder="Enter your email"
                value={email}
                onChange={e => setEmail(e.target.value)}
                required
                style={{ width: '100%', padding: '12px 14px', border: '1.5px solid #e2e8f0', borderRadius: 8, fontSize: 14, boxSizing: 'border-box', transition: 'border 0.2s' }} />
            </div>

            <div style={{ marginBottom: 28 }}>
              <label style={{ fontSize: 13, fontWeight: 600, color: '#374151', display: 'block', marginBottom: 8 }}>
                Password
              </label>
              <div style={{ position: 'relative' }}>
                <input
                  type={showPass ? 'text' : 'password'}
                  placeholder="Enter your password"
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  required
                  style={{ width: '100%', padding: '12px 44px 12px 14px', border: '1.5px solid #e2e8f0', borderRadius: 8, fontSize: 14, boxSizing: 'border-box', transition: 'border 0.2s' }} />
                <button type="button" onClick={() => setShowPass(!showPass)}
                  style={{ position: 'absolute', right: 12, top: '50%', transform: 'translateY(-50%)', background: 'none', border: 'none', cursor: 'pointer', fontSize: 12, color: '#64748b', fontWeight: 600 }}>
                  {showPass ? 'Hide' : 'Show'}
                </button>
              </div>
            </div>

            <button type="submit" disabled={loading}
              style={{ width: '100%', padding: '13px', background: loading ? '#a5b4fc' : '#4f46e5', color: '#fff', border: 'none', borderRadius: 8, fontSize: 15, fontWeight: 600, cursor: loading ? 'not-allowed' : 'pointer', transition: 'background 0.2s', letterSpacing: 0.3 }}>
              {loading ? 'Signing in...' : 'Sign In'}
            </button>
          </form>

          <div style={{ marginTop: 32, padding: 16, background: '#f8fafc', borderRadius: 10, border: '1px solid #e2e8f0' }}>
            <p style={{ fontSize: 12, color: '#64748b', marginBottom: 8, fontWeight: 600 }}>Demo Credentials</p>
            <p style={{ fontSize: 12, color: '#94a3b8' }}>Email: new@test.com</p>
            <p style={{ fontSize: 12, color: '#94a3b8' }}>Password: test123</p>
          </div>

          <p style={{ textAlign: 'center', marginTop: 24, fontSize: 12, color: '#cbd5e1' }}>
            SMS Portal v1.0 · Student Management System
          </p>
        </div>
      </div>
    </div>
  )
}