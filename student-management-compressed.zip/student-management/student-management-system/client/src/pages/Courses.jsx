import { useEffect, useState } from 'react'
import { getCourses, createCourse } from '../services/api'
import { useNotification } from '../context/NotificationContext'

export default function Courses() {
  const [courses,  setCourses]  = useState([])
  const [showForm, setShowForm] = useState(false)
  const [name,     setName]     = useState('')
  const [code,     setCode]     = useState('')
  const [desc,     setDesc]     = useState('')
  const [credits,  setCredits]  = useState(3)
  const [loading,  setLoading]  = useState(false)
  const { addNotification } = useNotification()

  const fetchCourses = async () => {
    const { data } = await getCourses()
    setCourses(data)
  }

  useEffect(() => { fetchCourses() }, [])

  const handleAdd = async (e) => {
    e.preventDefault()
    setLoading(true)
    try {
      await createCourse({ name, code, description: desc, credits })
      setName(''); setCode(''); setDesc(''); setCredits(3)
      setShowForm(false)
      addNotification('Course added successfully!', 'success')
      fetchCourses()
    } catch {
      addNotification('Failed to add course!', 'error')
    }
    setLoading(false)
  }

  const inputStyle = {
    width: '100%', padding: '10px 14px',
    border: '1.5px solid #e2e8f0', borderRadius: 8,
    fontSize: 13, boxSizing: 'border-box', outline: 'none'
  }

  const labelStyle = {
    fontSize: 12, fontWeight: 600,
    color: '#64748b', display: 'block',
    marginBottom: 6, textTransform: 'uppercase',
    letterSpacing: 0.4
  }

  const deptColors = ['#4f46e5', '#0369a1', '#15803d', '#a16207', '#dc2626', '#7c3aed']

  return (
    <div className="fade-in" style={{ maxWidth: 1100, margin: '0 auto' }}>

      {/* Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 28 }}>
        <div>
          <p style={{ fontSize: 12, color: '#94a3b8', marginBottom: 4 }}>Home / Courses</p>
          <h2 style={{ fontSize: 22, fontWeight: 700, color: '#0f172a' }}>Courses</h2>
          <p style={{ fontSize: 13, color: '#94a3b8', marginTop: 4 }}>{courses.length} courses available</p>
        </div>
        <button onClick={() => setShowForm(!showForm)}
          style={{ padding: '10px 20px', background: '#4f46e5', color: '#fff', border: 'none', borderRadius: 8, fontSize: 13, fontWeight: 600, cursor: 'pointer' }}>
          + Add Course
        </button>
      </div>

      {/* Add Form */}
      {showForm && (
        <div style={{ background: '#fff', borderRadius: 12, padding: 24, marginBottom: 24, boxShadow: '0 1px 3px rgba(0,0,0,0.06)', border: '1px solid #f1f5f9' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
            <h3 style={{ fontSize: 15, fontWeight: 700, color: '#0f172a' }}>Add New Course</h3>
            <button onClick={() => setShowForm(false)}
              style={{ width: 28, height: 28, background: '#f1f5f9', border: 'none', borderRadius: 6, cursor: 'pointer', fontSize: 14, color: '#64748b' }}>
              x
            </button>
          </div>
          <form onSubmit={handleAdd}>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginBottom: 16 }}>
              <div>
                <label style={labelStyle}>Course Name</label>
                <input placeholder="e.g. Data Structures" value={name} onChange={e => setName(e.target.value)} style={inputStyle} required />
              </div>
              <div>
                <label style={labelStyle}>Course Code</label>
                <input placeholder="e.g. CS201" value={code} onChange={e => setCode(e.target.value)} style={inputStyle} required />
              </div>
              <div>
                <label style={labelStyle}>Description</label>
                <input placeholder="Brief description" value={desc} onChange={e => setDesc(e.target.value)} style={inputStyle} />
              </div>
              <div>
                <label style={labelStyle}>Credits</label>
                <select value={credits} onChange={e => setCredits(e.target.value)} style={inputStyle}>
                  {[1,2,3,4,5,6].map(c => <option key={c} value={c}>{c} Credits</option>)}
                </select>
              </div>
            </div>
            <div style={{ display: 'flex', gap: 10, justifyContent: 'flex-end' }}>
              <button type="button" onClick={() => setShowForm(false)}
                style={{ padding: '9px 20px', background: '#f1f5f9', color: '#64748b', border: 'none', borderRadius: 8, cursor: 'pointer', fontSize: 13, fontWeight: 500 }}>
                Cancel
              </button>
              <button type="submit" disabled={loading}
                style={{ padding: '9px 24px', background: '#4f46e5', color: '#fff', border: 'none', borderRadius: 8, cursor: 'pointer', fontSize: 13, fontWeight: 600 }}>
                {loading ? 'Saving...' : 'Add Course'}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Courses Table */}
      <div style={{ background: '#fff', borderRadius: 12, boxShadow: '0 1px 3px rgba(0,0,0,0.06)', overflow: 'hidden' }}>
        <table style={{ width: '100%', borderCollapse: 'collapse' }}>
          <thead>
            <tr style={{ borderBottom: '1px solid #f1f5f9', background: '#fafafa' }}>
              <th style={{ padding: '12px 20px', textAlign: 'left', fontSize: 11, color: '#94a3b8', fontWeight: 600, textTransform: 'uppercase', letterSpacing: 0.5 }}>Course</th>
              <th style={{ padding: '12px 20px', textAlign: 'left', fontSize: 11, color: '#94a3b8', fontWeight: 600, textTransform: 'uppercase', letterSpacing: 0.5 }}>Code</th>
              <th style={{ padding: '12px 20px', textAlign: 'left', fontSize: 11, color: '#94a3b8', fontWeight: 600, textTransform: 'uppercase', letterSpacing: 0.5 }}>Description</th>
              <th style={{ padding: '12px 20px', textAlign: 'left', fontSize: 11, color: '#94a3b8', fontWeight: 600, textTransform: 'uppercase', letterSpacing: 0.5 }}>Credits</th>
              <th style={{ padding: '12px 20px', textAlign: 'left', fontSize: 11, color: '#94a3b8', fontWeight: 600, textTransform: 'uppercase', letterSpacing: 0.5 }}>Teacher</th>
            </tr>
          </thead>
          <tbody>
            {courses.map((c, i) => (
              <tr key={c._id} style={{ borderBottom: '1px solid #f8fafc' }}>
                <td style={{ padding: '14px 20px' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                    <div style={{ width: 34, height: 34, background: `${deptColors[i % deptColors.length]}15`, borderRadius: 8, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 12, fontWeight: 700, color: deptColors[i % deptColors.length], flexShrink: 0 }}>
                      {c.code?.slice(0, 2)}
                    </div>
                    <div>
                      <div style={{ fontWeight: 500, fontSize: 13, color: '#0f172a' }}>{c.name}</div>
                    </div>
                  </div>
                </td>
                <td style={{ padding: '14px 20px' }}>
                  <span style={{ background: '#f1f5f9', color: '#4f46e5', padding: '3px 10px', borderRadius: 6, fontSize: 12, fontWeight: 600 }}>{c.code}</span>
                </td>
                <td style={{ padding: '14px 20px', fontSize: 13, color: '#64748b' }}>{c.description || '—'}</td>
                <td style={{ padding: '14px 20px', fontSize: 13, color: '#64748b' }}>{c.credits} credits</td>
                <td style={{ padding: '14px 20px', fontSize: 13, color: '#64748b' }}>{c.teacher?.name || 'Not assigned'}</td>
              </tr>
            ))}
          </tbody>
        </table>
        {courses.length === 0 && (
          <div style={{ textAlign: 'center', padding: 60, color: '#94a3b8' }}>
            <p style={{ fontSize: 16, fontWeight: 500, marginBottom: 6 }}>No courses yet</p>
            <p style={{ fontSize: 13 }}>Click Add Course to get started</p>
          </div>
        )}
      </div>
    </div>
  )
}