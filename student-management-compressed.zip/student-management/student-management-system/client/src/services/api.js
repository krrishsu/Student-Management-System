import axios from 'axios'

const API = axios.create({ baseURL: 'http://localhost:5000/api' })

API.interceptors.request.use((req) => {
  const user = JSON.parse(localStorage.getItem('user'))
  if (user?.token) req.headers.Authorization = `Bearer ${user.token}`
  return req
})

export const loginUser    = (data) => API.post('/auth/login', data)
export const registerUser = (data) => API.post('/auth/register', data)

export const getStudents   = ()          => API.get('/students')
export const createStudent = (data)      => API.post('/students', data)
export const updateStudent = (id, data)  => API.put(`/students/${id}`, data)
export const deleteStudent = (id)        => API.delete(`/students/${id}`)

export const getCourses    = ()          => API.get('/courses')
export const createCourse  = (data)      => API.post('/courses', data)