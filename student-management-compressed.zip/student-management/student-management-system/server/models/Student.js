const mongoose = require('mongoose');

const studentSchema = new mongoose.Schema({
  name:       { type: String, required: true },
  email:      { type: String, required: true, unique: true },
  rollNumber: { type: String, required: true, unique: true },
  phone:      { type: String },
  department: { type: String, required: true },
  year:       { type: Number, required: true },
  courses:    [{ type: mongoose.Schema.Types.ObjectId, ref: 'Course' }],
  grades: [{
    course: { type: mongoose.Schema.Types.ObjectId, ref: 'Course' },
    grade:  { type: String },
    marks:  { type: Number },
  }],
}, { timestamps: true });

module.exports = mongoose.model('Student', studentSchema);